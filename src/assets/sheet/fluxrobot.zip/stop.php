<?php require_once 'header.php'; 

?>
<script>
    window.onload = function () {
        responsiveVoice.speak("Congratulations! You have completed your daily exercises!", "US English Female");
    }
    </script>
<body>        
    <div><h1>Congrats!</h1></div>
    <div><h2>You have completed your daily exercises!</h2></div>

